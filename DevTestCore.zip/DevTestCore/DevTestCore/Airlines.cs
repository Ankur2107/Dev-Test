﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevTestCore
{
    class Airlines
    {
        public int id { get; set; }
        public string name { get; set; }
        public string country { get; set; }
        public string logo { get; set; }
        public string slogan { get; set; }
        public string head_quaters { get; set; }
        public string website { get; set; }
        public string established { get; set; }

    }
}
