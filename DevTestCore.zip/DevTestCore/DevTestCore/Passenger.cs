﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevTestCore
{
    public class Passenger
    {
        public int id { get; set; }
        public string name { get; set; }
        public int airlineId { get; set; }
        public string flightDate { get; set; }

    }
}
