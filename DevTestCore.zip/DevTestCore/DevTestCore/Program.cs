﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;

namespace DevTestCore
{

    class Program
    {
        static void Main(string[] args)
        {
            //REST API: https://6165a7fccb73ea0017642166.mockapi.io/api/v1/
            // endpoint: airlines -> methods: GET
            // endpoint: passengers -> methods: GET / POST

            //TODO
            // Print airline with the most passengers
            // Print top 3 airlines by most number of unflown passengers and the list the unflown passengers for each of these airlines sorted by flight date
            // Create new passenger for the airline with most passengers

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://6165a7fccb73ea0017642166.mockapi.io/api/v1/");

                //Called Member default GET All records  
                //GetAsync to send a GET request   
                // PutAsync to send a PUT request  
                var passengerresponse = client.GetAsync("passengers");
                passengerresponse.Wait();
                var airlinesresponse = client.GetAsync("airlines");
                airlinesresponse.Wait();


                //To store result of web api response.
                var passengerresult = passengerresponse.Result;
                var airlinesresult = airlinesresponse.Result;

                //If success received   
                if (passengerresult.IsSuccessStatusCode && airlinesresult.IsSuccessStatusCode)
                {

                    var passengerdata = passengerresult.Content.ReadAsStringAsync().Result;
                    var airlinesdata = airlinesresult.Content.ReadAsStringAsync().Result;
                    var passengerobj = JsonSerializer.Deserialize<IList<Passenger>>(passengerdata);
                    var airlinesobj = JsonSerializer.Deserialize<IList<Airlines>>(airlinesdata);
                    var maximumpassenger = passengerobj.GroupBy(t => t.airlineId)
                            .Select(t => new
                            {
                                airlineid = t.Key,
                                Count = t.Count(),

                            }).OrderByDescending(Item => Item.Count).ToList();
                    var airlineId = maximumpassenger[0].airlineid;
                    var airline = airlinesobj.Where(x => x.id == airlineId).FirstOrDefault().name;
                    Console.WriteLine("Airline with the most passengers: " + airline);

                    var mimimumpassenger = passengerobj.GroupBy(t => t.airlineId)
                            .Select(t => new
                            {
                                airlineid = t.Key,
                                Count = t.Count(),

                            }).OrderBy(Item => Item.Count).ToList();

                    var unflownlist = mimimumpassenger.Take(3).ToList();
                    Console.WriteLine();
                    Console.WriteLine("Airlines with most number of unflown passengers :");
                    foreach (var item in unflownlist)
                    {

                        Console.WriteLine("Airline id: " + item.airlineid);
                        var passengerlist = passengerobj.Where(x => x.airlineId == item.airlineid).OrderBy(x => x.flightDate).ToList();
                        foreach (var passenger in passengerlist)
                        {
                            Console.WriteLine("  Passenger Name: " + passenger.name + " flight date: " + passenger.flightDate);
                        }
                        Console.WriteLine();
                    }


                    Passenger newpassenger = new Passenger();
                    newpassenger.id = passengerobj.Count + 1;
                    newpassenger.name = "Ankur";
                    newpassenger.airlineId = airlineId;
                    newpassenger.flightDate = "2022-07-08T02:39:36 -02:00";

                    passengerobj.Add(newpassenger);

                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine(passengerresult.StatusCode);
                    Console.WriteLine(airlinesresult.StatusCode);
                }
            }




        }
    }
}
